package automate.automatite;

/**
 * Hello world!
 *
 */

import java.util.concurrent.TimeUnit;

//import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;


public class App {
	public static void main(String[] args) {
		String key="webdriver.chrome.driver";
		String value="/*change here*/";
		System.setProperty(key, value);
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
//		driver.findElement(By.id("username")).sendKeys("something");
//		driver.findElement(By.id("password")).sendKeys("password!");
//		driver.findElement(By.xpath("/html/body/div[2]/div/div/form/button")).click();
//		Assert.assertEquals(driver.getCurrentUrl(), "https://the-internet.herokuapp.com/login");
		
		driver.get("https://the-internet.herokuapp.com/login");
		WebElement c=driver.findElement(By.xpath("//input[@name='username']"));
		c.sendKeys("tomsmith");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("SuperSecretPassword!");
		driver.findElement(By.xpath("//i")).click();
		driver.findElement(By.xpath("//a[@class='button secondary radius']")).click();
		driver.navigate().back();
		String cnfirm=driver.findElement(By.xpath("//div[@id='flash']")).getText();
		if(cnfirm.contains("You logged into a secure area!"))
		{
			driver.close();
			System.out.println("\n Adhoc_Test_Case Failed \n\n Defect Found\n");
			throw new ArithmeticException("\nAdhoc_Test_Case Failed \n \nDefect Found \n");
		}
		else {
			System.out.println("\n Adhoc_Test_Case Passed");
		}
		driver.close();
		
	}


}